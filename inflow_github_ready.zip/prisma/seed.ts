import { prisma } from "../lib/prisma"
async function main(){
  // no-op seed
}
main().finally(()=>process.exit(0))
